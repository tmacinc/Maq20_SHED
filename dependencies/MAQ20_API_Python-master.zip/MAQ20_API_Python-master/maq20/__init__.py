from .maq20 import MAQ20
from .maq20module import MAQ20Module
from .maq20com import COMx
from .utilities import *

__version__ = '0.5.1'
